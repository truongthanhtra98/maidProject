import 'package:flutter/material.dart';
class Item {
  const Item(this.thoiGian, this.dienTich, this.soPhong);
  final String thoiGian;
  final String dienTich;
  final String soPhong;
}

class DropDownList extends StatefulWidget {
  @override
  _DropDownListState createState() => _DropDownListState();
}

class _DropDownListState extends State<DropDownList> {
  Item selectedAttribute;
  List<Item> attribute = <Item>[
    const Item("3h", "          15 m2", "         4 Phòng"),
    const Item("4h", "          20 m2", "         5 Phòng"),
    const Item("5h", "          25 m2", "         6 Phòng"),
    const Item("6h", "          30 m2", "         7 Phòng"),
  ];
  @override
  Widget build(BuildContext context) {
    return Center(
        child: DropdownButton<Item>(
          hint: Text("                  Làm Trong"),
          value: selectedAttribute,
          onChanged: (Item Value) {
            setState(() {
              selectedAttribute = Value;
            });
          },
          items: attribute.map((Item attribute) {
            return DropdownMenuItem<Item>(
              value: attribute,
              child: Row(
                children: <Widget>[
                  Text(
                    attribute.thoiGian,
                    style: TextStyle(color: Colors.black),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    attribute.dienTich,
                    style: TextStyle(color: Colors.black),
                  ),
                  Text(
                    attribute.soPhong,
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
            );
          }).toList(),
        ));
  }
}