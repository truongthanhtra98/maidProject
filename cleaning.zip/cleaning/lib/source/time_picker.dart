import 'package:flutter/material.dart';
class timePicker extends StatefulWidget {
  @override
  _timePickerState createState() => _timePickerState();
}

class _timePickerState extends State<timePicker> {

  TimeOfDay _time = new TimeOfDay.now();
  @override


  Future<Null> selectTime(BuildContext context) async {
    final TimeOfDay picked = await showTimePicker(
      context: context,
      initialTime: _time,
    );
    if (picked != null && picked != _time) {
      print("Time selected : ${_time.toString()}");

      setState(() {
        _time = picked;
      });
    }
  }

  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: <Widget>[
          RaisedButton(
            child: new Text("{$_time}"),
            onPressed: () {
              selectTime(context);
            },
          ),
        ],
      ),
    );
  }
}