import 'package:flutter/material.dart';
class switchButton extends StatefulWidget {
  @override
  _switchButtonState createState() => _switchButtonState();
}

class _switchButtonState extends State<switchButton> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Switch(
          activeColor: Colors.orange,
          value: status,
          onChanged: (value) {
            setState(() {
              status = value;
            });
          },
        ),
      ],
    );
  }
}