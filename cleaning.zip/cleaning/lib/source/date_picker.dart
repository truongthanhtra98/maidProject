import 'package:flutter/material.dart';

class datePicker extends StatefulWidget {
  @override
  _datePickerState createState() => _datePickerState();
}

class _datePickerState extends State<datePicker> {
  DateTime _date = new DateTime.now();

  @override
  Future<Null> selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: new DateTime(1975),
      lastDate: new DateTime(2100),
    );
    if (picked != null && picked != _date) {
      print("Date selected : ${_date.toString()}");

      setState(() {
        _date = picked;
      });
    }
  }



  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: <Widget>[
          RaisedButton(
            child: new Text("Ngày"),
            onPressed: () {
              selectDate(context);
            },
          ),
        ],
      ),
    );
  }
}