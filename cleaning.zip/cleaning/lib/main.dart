import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'source/date_picker.dart';
import 'source/time_picker.dart';
import 'source/switch_button.dart';
import 'source/dropdown_list.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Cleaning(),
  ));
}

class Cleaning extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.orange,
        title: Center(
          child: Text(
            "Cleaning",
            style: TextStyle(color: Colors.white, fontStyle: FontStyle.italic),
          ),
        ),
        elevation: 0.0,
      ),
      body: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(50), topRight: Radius.circular(50.0)),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.9),
                  blurRadius: 20.0,
                  spreadRadius: 5.0,
                  offset: Offset(10.0, 10.0))
            ]),
        child: Column(
          children: <Widget>[
            Container(
              margin: EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                  color: Colors.white70,
                  borderRadius: BorderRadius.circular(20.0)),
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextField(
                      decoration: new InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: new BorderSide(color: Colors.teal),
                            borderRadius: BorderRadius.circular(20.0)),
                        hintText: "Khu phố 6, Linh Trung, Thủ Đức",
                        labelText: "Địa Chỉ",
                        prefixIcon: Icon(Icons.location_city),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextField(
                      decoration: new InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: new BorderSide(color: Colors.teal),
                            borderRadius: BorderRadius.circular(20.0)),
                        hintText: "Phòng 35 Chung Cư Lê Văn Việt",
                        labelText: "Số Nhà/Căn Hộ",
                        prefixIcon: Icon(Icons.confirmation_number),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          margin: EdgeInsets.all(10.0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  blurRadius: 20.0,
                                  offset: Offset(0, 10.0),
                                )
                              ]),
                          height: 80.0,
                          width: 170.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "Ngày Mai",
                                style: TextStyle(
                                    color: Colors.orange, fontSize: 20.0),
                              ),
                              datePicker(),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          margin: EdgeInsets.all(10.0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  blurRadius: 20.0,
                                  offset: Offset(0, 10.0),
                                )
                              ]),
                          height: 80.0,
                          width: 170.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "Chọn Giờ Làm",
                                style: TextStyle(
                                    color: Colors.orange, fontSize: 20.0),
                              ),
                              timePicker(),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                          margin: EdgeInsets.all(10.0),
                          height: 70.0,
                          width: 380.0,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  blurRadius: 20.0,
                                  offset: Offset(0, 10.0),
                                )
                              ]),
                          child: new DropDownList())
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.all(10.0),
                        height: 100.0,
                        width: 110.0,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                blurRadius: 20.0,
                                offset: Offset(0, 10.0),
                              )
                            ]),
                        child: Icon(Icons.local_cafe),
                      ),
                      Container(
                        margin: EdgeInsets.all(10.0),
                        height: 100.0,
                        width: 110.0,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                blurRadius: 20.0,
                                offset: Offset(0, 10.0),
                              )
                            ]),
                        child: Icon(Icons.local_cafe),
                      ),
                      Container(
                        margin: EdgeInsets.all(10.0),
                        height: 100.0,
                        width: 110.0,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                blurRadius: 20.0,
                                offset: Offset(0, 10.0),
                              )
                            ]),
                        child: Icon(Icons.local_cafe),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Lặp lại hằng tuần",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                  Text(
                                    "Nghĩa là gì?",
                                    style: TextStyle(
                                        color: Colors.blue, fontSize: 15),
                                  )
                                ],
                              ),
                              SizedBox(
                                width: 150,
                              ),
                              switchButton(),
                            ],
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Lặp lại hằng tuần",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                  Text(
                                    "Nghĩa là gì?",
                                    style: TextStyle(
                                        color: Colors.blue, fontSize: 12),
                                  )
                                ],
                              ),
                              SizedBox(
                                width: 150,
                              ),
                              switchButton(),
                            ],
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Lặp lại hằng tuần",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                  Text(
                                    "Nghĩa là gì?",
                                    style: TextStyle(
                                        color: Colors.blue, fontSize: 12),
                                  )
                                ],
                              ),
                              SizedBox(
                                width: 150,
                              ),
                              switchButton(),
                            ],
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
